===MAP MOD for MINETEST-C55===
by PilzAdam

Version 1

Introduction:
This mod adds a map of the world to Minetest.

How to install:
Unzip the archive an place it in minetest-base-directory/mods/minetest/
if you have a windows client or a linux run-in-place client. If you have
a linux system-wide instalation place it in ~/.minetest/mods/minetest/.
If you want to install this mod only in one world create the folder
worldmods/ in your worlddirectory.
For further information or help see:
http://wiki.minetest.com/wiki/Installing_Mods

How to use the mod:
This mod will create a image of the map with the minetestmapper python
script. You need to have python installed to use this mod. The first start
may take some time because the mod creates the image of the map. When you
need a updated version of the map just delete the file "map.png" in
map/textures/.
To see the map in the game you can craft a map:
paper	paper
paper	paper

License:
minetestmapper.py: See line 4-8 in the script
Other sourcecode: WTFPL (see below)

See also:
http://minetest.net/

         DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO. 
