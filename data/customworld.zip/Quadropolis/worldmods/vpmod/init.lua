minetest.register_node("vpmod:ica", {
	description = "ICA",
	drawtype = "signlike",
	walkable = false,
	tiles = {"ica.png"},
	wield_image =  "ica.png",
	inventory_image =  "ica.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});

minetest.register_node("vpmod:bica", {
	description = "Bike Track",
	drawtype = "signlike",
	walkable = false,
	tiles = {"bica.png"},
	wield_image =  "bica.png",
	inventory_image =  "bica.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});

minetest.register_node("vpmod:bic", {
	description = "Bike",
	drawtype = "signlike",
	walkable = false,
	tiles = {"bic.png"},
	wield_image =  "bic.png",
	inventory_image =  "bic.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});

minetest.register_node("vpmod:tan", {
	description = "Gas Station",
	drawtype = "signlike",
	walkable = false,
	tiles = {"tan.png"},
	wield_image =  "tan.png",
	inventory_image =  "tan.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});

minetest.register_node("vpmod:pol", {
	description = "Police",
	drawtype = "signlike",
	walkable = false,
	tiles = {"pol.png"},
	wield_image =  "pol.png",
	inventory_image =  "pol.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});

minetest.register_node("vpmod:wifi", {
	description = "Wi-Fi",
	drawtype = "signlike",
	walkable = false,
	tiles = {"wifi.png"},
	wield_image =  "wifi.png",
	inventory_image =  "wifi.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});

minetest.register_node("vpmod:s30", {
	description = "Speed Limit 30",
	drawtype = "signlike",
	walkable = false,
	tiles = {"s30.png"},
	wield_image =  "s30.png",
	inventory_image =  "s30.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});
minetest.register_node("vpmod:s80", {
	description = "Speed Limit 80",
	drawtype = "signlike",
	walkable = false,
	tiles = {"s80.png"},
	wield_image =  "s80.png",
	inventory_image =  "s80.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});

minetest.register_node("vpmod:se", {
	description = "Seven Eleven",
	drawtype = "signlike",
	walkable = false,
	tiles = {"seveneleven.png"},
	wield_image =  "seveneleven.png",
	inventory_image =  "seveneleven.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});

minetest.register_node("vpmod:se2", {
	description = "7-11 Two",
	tile_images = {"se2.png"},
	inventory_image = minetest.inventorycube("se2.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})

minetest.register_node("vpmod:se1", {
	description = "7-11 One",
	tile_images = {"se1.png"},
	inventory_image = minetest.inventorycube("se1.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})

minetest.register_node("vpmod:bus", {
	description = "Bus Station sign",
	drawtype = "signlike",
	walkable = false,
	tiles = {"bus.png"},
	wield_image =  "bus.png",
	inventory_image =  "bus.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3}, 
});

minetest.register_node("vpmod:cwool", {
	description = "cwool",
	tile_images = {"cwool.png"},
	inventory_image = minetest.inventorycube("cwool.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})

minetest.register_node("vpmod:ccwool", {
	description = "ccwool",
	tile_images = {"ccwool.png"},
	inventory_image = minetest.inventorycube("ccwool.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})

minetest.register_node("vpmod:nglasi", {
	description = "Glass",
	drawtype = "glasslike",
	tile_images = {"nglas.png"},
	inventory_image = minetest.inventorycube("nglas.png"),
	paramtype = "light",
	light_source = LIGHT_MAX-1,
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_node("vpmod:dsb", {
	description = "dsb",
	tile_images = {"dsb.png"},
	inventory_image = minetest.inventorycube("dsb.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})

minetest.register_node("vpmod:dsg", {
	description = "dsg",
	tile_images = {"dsg.png"},
	inventory_image = minetest.inventorycube("dsg.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})


minetest.register_node("vpmod:leaves", {
	description = "leaves",
	tile_images = {"leaves.png"},
	inventory_image = minetest.inventorycube("leaves.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})

minetest.register_node("vpmod:dsv", {
	description = "dsv",
	tile_images = {"dsv.png"},
	inventory_image = minetest.inventorycube("dsv.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})

minetest.register_node("vpmod:lipp", {
	description = "city flag",
	drawtype = "torchlike",
	tile_images = {"lipp.png"},
	inventory_image = "lipp.png",
	wield_image = "lipp.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	walkable = false,
	light_source = LIGHT_MAX-1,
	selection_box = {
		type = "wallmounted",
		wall_top = {-0.1, 0.5-0.6, -0.1, 0.1, 0.5, 0.1},
		wall_bottom = {-0.1, -0.5, -0.1, 0.1, -0.5+0.6, 0.1},
		wall_side = {-0.5, -0.3, -0.1, -0.5+0.3, 0.3, 0.1},
	},
	groups = {choppy=2,dig_immediate=3,flammable=1,cracky=1},
	legacy_wallmounted = true,
	sounds = default.node_sound_defaults(),
})

minetest.register_node("vpmod:dss", {
	description = "dss",
	tile_images = {"dss.png"},
	inventory_image = minetest.inventorycube("dss.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})

minetest.register_node("vpmod:dsz", {
	description = "dsz",
	tile_images = {"dsz.png"},
	inventory_image = minetest.inventorycube("dsz.png"),
	is_ground_content = true,
	material = minetest.digprop_stonelike(1.0),
	dug_item = 'craft "default:clay_brick" 4',
	groups = {cracky=3}
})

print("VPMOD INIT OK")
